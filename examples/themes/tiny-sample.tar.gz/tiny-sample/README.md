# Tiny Sample

Upload the original `.tar.gz` at Admin > Themes and activate Tiny Sample.
To delete it, activate another theme first. No build tools are required.

Includes home, single content, blog, category, tag, search, and 404 templates;
one CSS file; an SVG preview; and the standard module hooks. Labels are English.
Public forms, widgets, custom menus, and theme settings are omitted.

Extract the archive to edit it. Repackage from the parent directory with:

```bash
COPYFILE_DISABLE=1 tar -czf tiny-sample.tar.gz tiny-sample
```

Copyright (c) 2026 Oleg Ivanchenko. SPDX-License-Identifier: GPL-3.0-or-later.
